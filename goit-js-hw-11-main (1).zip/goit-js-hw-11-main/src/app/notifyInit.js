export const notifyInit = {
  width: '250px',
  position: 'right-bottom',
  distance: '20px',
  timeout: 1500,
  opacity: 0.8,
  fontSize: '16px',
  borderRadius: '50px',
};
